sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.balta.ExampleApp.controller.DetailObjectNotFound", {});
});